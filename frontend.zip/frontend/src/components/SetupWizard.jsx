// SetupWizard component completely disabled
// This file exists but renders nothing to prevent import errors
import React from 'react';

export default function SetupWizard() {
    // DISABLED: Always return null to never show the wizard
    return null;
}
